package tau.cs.wolf.tibet.percentage_apbt.matching;

public enum ProcessType {
	ROW, COL
}